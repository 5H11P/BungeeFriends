# BungeeFriends API 使用说明

## 简介

这是BungeeFriends插件的API接口，允许其他插件访问和操作BungeeFriends的好友和组队功能。API提供了简单直观的方法来管理好友关系和组队操作。

## 使用方法

### 在你的插件中添加依赖

首先，确保你的插件依赖于BungeeFriends：

```java
@Override
public void onEnable() {
    if (getProxy().getPluginManager().getPlugin("BungeeFriends") == null) {
        getLogger().severe("BungeeFriends插件未找到，禁用插件...");
        getProxy().getPluginManager().unregisterListener(this, this);
        getProxy().getPluginManager().unregisterCommands(this);
        return;
    }
    // 你的插件初始化代码
}
```

### 获取API实例

```java
import net.simplyrin.bungeefriends.api.BungeeFriendsAPI;

// 获取API实例
BungeeFriendsAPI api = BungeeFriendsAPI.getInstance();
```

### 好友功能示例

```java
// 获取玩家的好友工具类
FriendUtils friendUtils = api.getFriendUtils(player);

// 检查两个玩家是否是好友
boolean areFriends = api.areFriends(player1, player2);

// 添加好友请求
try {
    api.addFriendRequest(sender, target);
    sender.sendMessage(new TextComponent("已发送好友请求给 " + target.getName()));
} catch (Exception e) {
    sender.sendMessage(new TextComponent("无法发送好友请求: " + e.getMessage()));
}

// 添加好友
try {
    api.addFriend(player1, player2);
} catch (Exception e) {
    // 处理异常
}

// 移除好友
try {
    api.removeFriend(player1, player2);
} catch (Exception e) {
    // 处理异常
}

// 获取好友列表
List<String> friends = api.getFriendList(player);
```

### 组队功能示例

```java
// 获取玩家的组队工具类
PartyUtils partyUtils = api.getPartyUtils(player);

// 检查玩家是否在组队中
boolean isInParty = api.isInParty(player);

// 邀请玩家加入组队
try {
    api.inviteToParty(leader, target);
} catch (Exception e) {
    // 处理异常
}

// 将玩家添加到组队
try {
    api.addToParty(leader, member);
} catch (Exception e) {
    // 处理异常
}

// 从组队中移除玩家
try {
    api.removeFromParty(leader, member);
} catch (Exception e) {
    // 处理异常
}

// 获取组队成员列表
List<String> members = api.getPartyMembers(player);

// 检查玩家是否是队长
boolean isLeader = api.isPartyLeader(player);

// 发送组队聊天消息
try {
    api.sendPartyChat(player, "Hello party members!");
} catch (NotJoinedException e) {
    player.sendMessage(new TextComponent("你不在任何组队中"));
}
```

## 测试命令

BungeeFriends API包含一个测试命令，可以用来测试API的功能：

- `/bfapi help` - 显示帮助信息
- `/bfapi friends` - 显示你的好友列表（通过API获取）
- `/bfapi party` - 显示你的组队信息（通过API获取）
- `/bfapi check <玩家名>` - 检查与指定玩家的好友关系
- `/bfapi checkparty <玩家名>` - 检查指定玩家的组队信息
- `/bfapi info` - 显示API信息

## 异常处理

API中的方法可能会抛出以下异常，你应该在代码中适当处理这些异常：

- `AlreadyAddedException` - 当尝试添加已经是好友的玩家时
- `FailedAddingException` - 当添加好友失败时
- `SelfException` - 当尝试对自己执行操作时
- `IgnoredException` - 当目标玩家已将你加入忽略列表时
- `FriendSlotLimitException` - 当好友数量达到上限时
- `RequestDenyException` - 当目标玩家拒绝接收请求时
- `NotAddedException` - 当尝试移除不是好友的玩家时
- `AlreadyJoinedException` - 当尝试邀请已经在组队中的玩家时
- `FailedInvitingException` - 当邀请玩家加入组队失败时
- `NotInvitedException` - 当尝试接受未收到的邀请时
- `NotJoinedException` - 当尝试对不在组队中的玩家执行操作时

## 注意事项

1. 确保在使用API前检查BungeeFriends插件是否已加载
2. 适当处理可能抛出的异常
3. 在插件禁用时释放资源

## 版本信息

- API版本: 1.0.0
- 兼容BungeeFriends版本: 2.4+
- 作者: SimplyRin (插件), Trae AI (API)