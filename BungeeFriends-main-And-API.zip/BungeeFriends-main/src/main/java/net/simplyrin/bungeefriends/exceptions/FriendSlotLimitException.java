package net.simplyrin.bungeefriends.exceptions;

/**
 * Created by SimplyRin on 2018/09/15.
 *
 * author: SimplyRin
 * license: LGPL v3
 * copyright: Copyright (c) 2021 SimplyRin
 */
public class FriendSlotLimitException extends Exception {

	public FriendSlotLimitException() {
	}

}
