package net.simplyrin.bungeefriends.messages;

/**
 * Created by SimplyRin on 2018/07/03.
 *
 * author: SimplyRin
 * license: LGPL v3
 * copyright: Copyright (c) 2021 SimplyRin
 */
public class Permissions {

	public static final String MAIN = "friends.command.main";
	public static final String ADMIN = "friends.command.admin";

}
