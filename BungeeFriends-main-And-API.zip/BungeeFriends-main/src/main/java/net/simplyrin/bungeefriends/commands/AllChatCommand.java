package net.simplyrin.bungeefriends.commands;

import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;
import net.simplyrin.bungeefriends.Main;
import net.simplyrin.bungeefriends.commands.ChatCommand.Channel;
import net.simplyrin.bungeefriends.messages.Messages;
import net.simplyrin.bungeefriends.tools.ThreadPool;
import net.simplyrin.bungeefriends.utils.LanguageManager.LanguageUtils;

/**
 * Created by Trae AI on 2023/07/10.
 *
 * author: Trae AI
 * license: LGPL v3
 * copyright: Copyright (c) 2023 Trae AI
 */
public class AllChatCommand extends Command {

	private Main plugin;

	public AllChatCommand(Main plugin, String cmd) {
		super(cmd, null);
		this.plugin = plugin;
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		ThreadPool.run(() -> this.async(sender, args));
	}

	public void async(CommandSender sender, String[] args) {
		if (!(sender instanceof ProxiedPlayer)) {
			this.plugin.info(Messages.INGAME_ONLY);
			return;
		}

		ProxiedPlayer player = (ProxiedPlayer) sender;
		LanguageUtils langUtils = this.plugin.getLanguageManager().getPlayer(player);

		// 如果是/achat ac命令，切换到全局聊天频道
		if (args.length == 1 && args[0].equalsIgnoreCase("ac")) {
			this.plugin.getChatCommand().getChannels().remove(player.getUniqueId());
			this.plugin.info(player, langUtils.getString(Messages.HYPHEN));
			this.plugin.info(player, langUtils.getString("Chat.Update").replace("%CHANNEL%", langUtils.getString("Chat.Channels.All")));
			this.plugin.info(player, langUtils.getString(Messages.HYPHEN));
			return;
		}

		// 如果玩家当前在组队聊天频道，发送全局消息
		if (args.length > 0) {
			String message = "";
			for (int i = 0; i < args.length; i++) {
				message += args[i] + " ";
			}
			message = message.trim();

			// 临时保存当前频道
			Channel currentChannel = this.plugin.getChatCommand().getChannels().get(player.getUniqueId());
			
			// 临时切换到全局频道发送消息
			this.plugin.getChatCommand().getChannels().remove(player.getUniqueId());
			
			// 发送消息
			player.chat(message);
			
			// 恢复原来的频道
			if (currentChannel != null) {
				this.plugin.getChatCommand().getChannels().put(player.getUniqueId(), currentChannel);
			}
			return;
		}

		// 显示用法
		this.plugin.info(player, langUtils.getString(Messages.HYPHEN));
		this.plugin.info(player, langUtils.getString("Chat.AllChatUsage"));
		this.plugin.info(player, langUtils.getString(Messages.HYPHEN));
		return;
	}

}