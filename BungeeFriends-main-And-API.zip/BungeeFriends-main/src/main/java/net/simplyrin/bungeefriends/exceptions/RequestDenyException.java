package net.simplyrin.bungeefriends.exceptions;

/**
 * Created by SimplyRin on 2019/01/06.
 *
 * author: SimplyRin
 * license: LGPL v3
 * copyright: Copyright (c) 2021 SimplyRin
 */
public class RequestDenyException extends Exception {

	public RequestDenyException() {
	}

}
