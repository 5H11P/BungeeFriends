# 组队人数限制配置

## 新增功能

本次更新为 BungeeFriends 插件添加了可配置的最大组队人数限制功能。

## 配置说明

### config.yml 配置项

```yaml
Plugin:
  Party-Max-Size: "10"  # 最大组队人数，默认为10人
```

### 配置说明

- `Party-Max-Size`: 设置组队允许的最大玩家数量
- 默认值: 10
- 类型: 字符串（会被自动转换为整数）
- 范围: 建议设置为 2-50 之间的合理数值

## 功能特性

1. **可配置限制**: 管理员可以通过修改 config.yml 中的 `Party-Max-Size` 来自定义最大组队人数

2. **实时检查**: 当玩家尝试邀请其他玩家加入组队时，系统会自动检查当前组队人数是否已达上限

3. **友好提示**: 当组队人数达到上限时，会显示相应的错误消息：
   - 中文: "&c组队人数已达上限！无法添加更多玩家！"
   - 英文: "&cParty is full! Cannot add more players!"

4. **向后兼容**: 如果配置文件中没有此项设置，系统会自动使用默认值 10

## 技术实现

### 修改的文件

1. **ConfigManager.java**
   - 添加了 `Plugin.Party-Max-Size` 的默认配置
   - 在配置重置方法中添加了相应的重置逻辑

2. **PartyManager.java**
   - 在 `add()` 方法中添加了人数限制检查
   - 当达到上限时抛出 `FailedAddingException` 异常

3. **语言文件**
   - Chinese.yml: 添加了 `Exceptions.Party-Full` 中文错误消息
   - English.yml: 添加了 `Exceptions.Party-Full` 英文错误消息

### 检查逻辑

```java
// 检查队伍人数限制
int maxSize = Integer.parseInt(plugin.getConfigManager().getConfig().getString("Plugin.Party-Max-Size", "10"));
if (list.size() + 1 >= maxSize) { // +1 因为队长也算一个人
    throw new FailedAddingException("Exceptions.Party-Full");
}
```

## 使用方法

1. 修改 `config.yml` 中的 `Party-Max-Size` 值
2. 重启服务器或重载插件配置
3. 新的限制将立即生效

## 注意事项

- 队长本身也计算在组队人数内
- 修改配置后需要重启服务器或重载配置才能生效
- 建议根据服务器性能和游戏平衡性合理设置人数上限