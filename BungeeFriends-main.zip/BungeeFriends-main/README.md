# BungeeFriends
某サーバーっぽいフレンドシステム

# スクリーンショット
![40cac0c3318775e8050ac84c54cca0f1](https://i.gyazo.com/40cac0c3318775e8050ac84c54cca0f1.png "40cac0c3318775e8050ac84c54cca0f1")


![03bd2a90ad316fbe87afb9693fa546fd](https://i.gyazo.com/03bd2a90ad316fbe87afb9693fa546fd.png "03bd2a90ad316fbe87afb9693fa546fd")


![f0d350242ec2e3d60e3c9cf34da3f71f](https://i.gyazo.com/f0d350242ec2e3d60e3c9cf34da3f71f.png "0d350242ec2e3d60e3c9cf34da3f71f")

# Open Source Lisence
**・[bStats-Metrics | GNU Lesser General Public License v3.0](https://github.com/Bastian/bStats-Metrics/blob/master/LICENSE)**

**・[LuckPerms | MIT License](https://raw.githubusercontent.com/lucko/LuckPerms/master/LICENSE.txt)**
