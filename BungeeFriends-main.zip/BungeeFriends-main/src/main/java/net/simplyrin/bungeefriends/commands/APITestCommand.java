package net.simplyrin.bungeefriends.commands;

import java.util.List;
import java.util.UUID;

import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;
import net.md_5.bungee.api.plugin.TabExecutor;
import net.simplyrin.bungeefriends.Main;
import net.simplyrin.bungeefriends.api.BungeeFriendsAPI;
import net.simplyrin.bungeefriends.api.BungeeFriendsAPI.FriendInfo;
import net.simplyrin.bungeefriends.api.BungeeFriendsAPI.PartyMemberInfo;
import net.simplyrin.bungeefriends.exceptions.NotAddedException;
import net.simplyrin.bungeefriends.exceptions.SelfException;
import net.simplyrin.bungeefriends.exceptions.parties.NotJoinedException;
import net.simplyrin.bungeefriends.messages.Permissions;
import net.simplyrin.bungeefriends.utils.FriendManager.FriendUtils;
import net.simplyrin.bungeefriends.utils.LanguageManager.LanguageUtils;
import net.simplyrin.bungeefriends.utils.PartyManager.PartyUtils;

import java.util.ArrayList;

/**
 * BungeeFriends API测试命令
 * 
 * @author Trae AI
 * @version 1.0.0
 */
public class APITestCommand extends Command implements TabExecutor {

    private Main plugin;
    private BungeeFriendsAPI api;

    public APITestCommand(Main plugin) {
        super("bfapi", Permissions.ADMIN, "bungeefriends-api");
        this.plugin = plugin;
        this.api = BungeeFriendsAPI.getInstance();
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof ProxiedPlayer)) {
            sender.sendMessage(new TextComponent(ChatColor.RED + "此命令只能由玩家执行！"));
            return;
        }

        ProxiedPlayer player = (ProxiedPlayer) sender;
        LanguageUtils langUtils = plugin.getLanguageManager().getPlayer(player.getUniqueId());

        if (!player.hasPermission(Permissions.ADMIN)) {
            plugin.info(player, langUtils.getString("No-Permission"));
            return;
        }

        if (args.length == 0) {
            sendHelp(player);
            return;
        }

        switch (args[0].toLowerCase()) {
            case "help":
                sendHelp(player);
                break;
            case "friends":
                showFriends(player);
                break;
            case "frienddetails":
                showFriendDetails(player);
                break;
            case "frienddetailsbyname":
                if (args.length < 2) {
                    plugin.info(player, "&c用法: /bfapi frienddetailsbyname <玩家名称>");
                    return;
                }
                showFriendDetailsByName(player, args[1]);
                break;
            case "party":
                showParty(player);
                break;
            case "partydetails":
                showPartyDetails(player);
                break;
            case "partydetailsbyname":
                if (args.length < 2) {
                    plugin.info(player, "&c用法: /bfapi partydetailsbyname <玩家名称>");
                    return;
                }
                showPartyDetailsByName(player, args[1]);
                break;
            case "check":
                if (args.length < 2) {
                    plugin.info(player, "&c用法: /bfapi check <玩家名>");
                    return;
                }
                checkFriend(player, args[1]);
                break;
            case "checkparty":
                if (args.length < 2) {
                    plugin.info(player, "&c用法: /bfapi checkparty <玩家名>");
                    return;
                }
                checkParty(player, args[1]);
                break;
            case "info":
                showAPIInfo(player);
                break;
            default:
                sendHelp(player);
                break;
        }
    }

    private void sendHelp(ProxiedPlayer player) {
        plugin.info(player, "&9----------------------------------------------------");
        plugin.info(player, "&e/bfapi help &7- 显示帮助信息");
        plugin.info(player, "&e/bfapi friends &7- 显示你的好友列表");
        plugin.info(player, "&e/bfapi frienddetails &7- 显示你的好友详细信息列表");
        plugin.info(player, "&e/bfapi frienddetailsbyname <玩家名> &7- 显示指定玩家的好友详细信息列表");
        plugin.info(player, "&e/bfapi party &7- 显示你的组队信息");
        plugin.info(player, "&e/bfapi partydetails &7- 显示你的组队成员详细信息列表");
        plugin.info(player, "&e/bfapi partydetailsbyname <玩家名> &7- 显示指定玩家的组队成员详细信息列表");
        plugin.info(player, "&e/bfapi check <玩家名> &7- 检查与指定玩家的好友关系");
        plugin.info(player, "&e/bfapi checkparty <玩家名> &7- 检查指定玩家的组队信息");
        plugin.info(player, "&e/bfapi info &7- 显示API信息");
        plugin.info(player, "&9----------------------------------------------------");
    }

    private void showFriends(ProxiedPlayer player) {
        FriendUtils friendUtils = api.getFriendUtils(player);
        List<String> friends = friendUtils.getFriends();

        plugin.info(player, "&6=== 你的好友列表 (通过API) ===");
        if (friends.isEmpty()) {
            plugin.info(player, "&7你还没有好友。");
            return;
        }

        for (String friendUUID : friends) {
            UUID uuid = UUID.fromString(friendUUID);
            FriendUtils friend = plugin.getFriendManager().getPlayer(uuid);
            ProxiedPlayer friendPlayer = plugin.getProxy().getPlayer(uuid);
            String status = friendPlayer != null ? "&a在线" : "&c离线";
            String server = friendPlayer != null ? "&7(" + friendPlayer.getServer().getInfo().getName() + ")" : "";
            plugin.info(player, "&7- " + friend.getDisplayName() + " &7[" + status + "&7]" + server);
        }
    }

    private void showFriendDetails(ProxiedPlayer player) {
        List<FriendInfo> friendDetails = api.getFriendDetailList(player);

        plugin.info(player, "&6=== 你的好友详细信息列表 (通过API) ===");
        if (friendDetails.isEmpty()) {
            plugin.info(player, "&7你还没有好友。");
            return;
        }

        for (FriendInfo friend : friendDetails) {
            String status = friend.isOnline() ? "&a在线" : "&c离线";
            plugin.info(player, "&7- " + friend.getDisplayName() + " &7[" + status + "&7]");
            plugin.info(player, "  &8UUID: &7" + friend.getUuid());
            plugin.info(player, "  &8名称: &7" + friend.getName());
            plugin.info(player, "  &8前缀: &7" + friend.getPrefix());
        }
    }

    private void showFriendDetailsByName(ProxiedPlayer player, String targetName) {
        List<FriendInfo> friendDetails = api.getFriendDetailListByName(targetName);

        plugin.info(player, "&6=== " + targetName + " 的好友详细信息列表 (通过API) ===");
        if (friendDetails == null) {
            plugin.info(player, "&c找不到玩家 " + targetName + " 的信息。");
            return;
        }
        if (friendDetails.isEmpty()) {
            plugin.info(player, "&7该玩家还没有好友。");
            return;
        }

        for (FriendInfo friend : friendDetails) {
            String status = friend.isOnline() ? "&a在线" : "&c离线";
            plugin.info(player, "&7- " + friend.getDisplayName() + " &7[" + status + "&7]");
            plugin.info(player, "  &8UUID: &7" + friend.getUuid());
            plugin.info(player, "  &8名称: &7" + friend.getName());
            plugin.info(player, "  &8前缀: &7" + friend.getPrefix());
        }
    }

    private void showParty(ProxiedPlayer player) {
        PartyUtils partyUtils = api.getPartyUtils(player);

        if (!partyUtils.isJoinedParty()) {
            plugin.info(player, "&c你当前不在任何组队中。");
            return;
        }

        try {
            PartyUtils leader = partyUtils.getPartyLeader();
            boolean isLeader = partyUtils.isPartyOwner();
            List<String> members = leader.getParties();

            plugin.info(player, "&6=== 你的组队信息 (通过API) ===");
            plugin.info(player, "&e队长: &7" + leader.getDisplayName() + (isLeader ? " &a(你)" : ""));
            plugin.info(player, "&e成员数量: &7" + (members.size() + 1));
            plugin.info(player, "&e在线成员: &7" + leader.getOnlinePlayers());
            plugin.info(player, "&e成员列表:");

            // 显示队长
            if (!isLeader) {
                plugin.info(player, "&7- " + leader.getDisplayName() + " &6[队长]");
            }

            // 显示成员
            for (String memberUUID : members) {
                UUID uuid = UUID.fromString(memberUUID);
                FriendUtils member = plugin.getFriendManager().getPlayer(uuid);
                boolean isYou = uuid.equals(player.getUniqueId());
                ProxiedPlayer memberPlayer = plugin.getProxy().getPlayer(uuid);
                String status = memberPlayer != null ? "&a在线" : "&c离线";
                plugin.info(player, "&7- " + member.getDisplayName() + (isYou ? " &a(你)" : "") + " &7[" + status + "&7]");
            }
        } catch (NotJoinedException e) {
            plugin.info(player, "&c获取组队信息时出错: " + e.getMessage());
        }
    }

    private void showPartyDetails(ProxiedPlayer player) {
        List<PartyMemberInfo> partyDetails = api.getPartyMemberDetailList(player);

        if (partyDetails.isEmpty()) {
            plugin.info(player, "&c你当前不在任何组队中。");
            return;
        }

        plugin.info(player, "&6=== 你的组队成员详细信息列表 (通过API) ===");
        plugin.info(player, "&e成员数量: &7" + partyDetails.size());

        for (PartyMemberInfo member : partyDetails) {
            String status = member.isOnline() ? "&a在线" : "&c离线";
            String leaderTag = member.isLeader() ? " &6[队长]" : "";
            boolean isYou = member.getUuid().equals(player.getUniqueId());
            String youTag = isYou ? " &a(你)" : "";
            
            plugin.info(player, "&7- " + member.getDisplayName() + youTag + leaderTag + " &7[" + status + "&7]");
            plugin.info(player, "  &8UUID: &7" + member.getUuid());
            plugin.info(player, "  &8名称: &7" + member.getName());
        }
    }

    private void showPartyDetailsByName(ProxiedPlayer player, String targetName) {
        List<PartyMemberInfo> partyDetails = api.getPartyMemberDetailListByName(targetName);

        if (partyDetails == null) {
            plugin.info(player, "&c找不到玩家 " + targetName + " 的信息。");
            return;
        }
        if (partyDetails.isEmpty()) {
            plugin.info(player, "&c该玩家当前不在任何组队中。");
            return;
        }

        plugin.info(player, "&6=== " + targetName + " 的组队成员详细信息列表 (通过API) ===");
        plugin.info(player, "&e成员数量: &7" + partyDetails.size());

        for (PartyMemberInfo member : partyDetails) {
            String status = member.isOnline() ? "&a在线" : "&c离线";
            String leaderTag = member.isLeader() ? " &6[队长]" : "";
            boolean isTarget = member.getName().equalsIgnoreCase(targetName);
            String youTag = isTarget ? " &a(查询目标)" : "";
            
            plugin.info(player, "&7- " + member.getDisplayName() + youTag + leaderTag + " &7[" + status + "&7]");
            plugin.info(player, "  &8UUID: &7" + member.getUuid());
            plugin.info(player, "  &8名称: &7" + member.getName());
        }
    }

    private void checkFriend(ProxiedPlayer player, String targetName) {
        ProxiedPlayer target = plugin.getProxy().getPlayer(targetName);
        if (target == null) {
            plugin.info(player, "&c玩家 " + targetName + " 不在线。");
            return;
        }

        boolean areFriends = api.areFriends(player, target);
        FriendUtils targetUtils = api.getFriendUtils(target);

        plugin.info(player, "&6=== 好友关系检查 (通过API) ===");
        plugin.info(player, "&e玩家: &7" + targetUtils.getDisplayName());
        plugin.info(player, "&e是否是好友: &7" + (areFriends ? "&a是" : "&c否"));

        if (areFriends) {
            // 如果是好友，提供移除选项
            TextComponent message = new TextComponent(ChatColor.translateAlternateColorCodes('&', "&e点击 "));
            TextComponent remove = new TextComponent(ChatColor.translateAlternateColorCodes('&', "&c[移除好友]"));
            remove.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/friend remove " + target.getName()));
            remove.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("点击移除好友").create()));
            message.addExtra(remove);

            player.sendMessage(message);
        } else {
            // 如果不是好友，提供添加选项
            TextComponent message = new TextComponent(ChatColor.translateAlternateColorCodes('&', "&e点击 "));
            TextComponent add = new TextComponent(ChatColor.translateAlternateColorCodes('&', "&a[添加好友]"));
            add.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/friend add " + target.getName()));
            add.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("点击添加好友").create()));
            message.addExtra(add);

            player.sendMessage(message);
        }
    }

    private void checkParty(ProxiedPlayer player, String targetName) {
        ProxiedPlayer target = plugin.getProxy().getPlayer(targetName);
        if (target == null) {
            plugin.info(player, "&c玩家 " + targetName + " 不在线。");
            return;
        }

        PartyUtils targetParty = api.getPartyUtils(target);
        boolean isInParty = targetParty.isJoinedParty();

        plugin.info(player, "&6=== 组队信息检查 (通过API) ===");
        plugin.info(player, "&e玩家: &7" + api.getFriendUtils(target).getDisplayName());
        plugin.info(player, "&e是否在组队中: &7" + (isInParty ? "&a是" : "&c否"));

        if (isInParty) {
            try {
                PartyUtils leader = targetParty.getPartyLeader();
                boolean isLeader = targetParty.isPartyOwner();
                List<String> members = leader.getParties();

                plugin.info(player, "&e队长: &7" + leader.getDisplayName() + (isLeader ? " &6(该玩家是队长)" : ""));
                plugin.info(player, "&e成员数量: &7" + (members.size() + 1));
                plugin.info(player, "&e在线成员: &7" + leader.getOnlinePlayers());

                // 如果你不在该组队中，提供加入选项
                PartyUtils playerParty = api.getPartyUtils(player);
                if (!playerParty.isJoinedParty() && !isLeader) {
                    TextComponent message = new TextComponent(ChatColor.translateAlternateColorCodes('&', "&e点击 "));
                    TextComponent join = new TextComponent(ChatColor.translateAlternateColorCodes('&', "&a[请求加入]"));
                    join.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/party join " + leader.getPlayer().getName()));
                    join.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("点击请求加入组队").create()));
                    message.addExtra(join);

                    player.sendMessage(message);
                }
            } catch (NotJoinedException e) {
                plugin.info(player, "&c获取组队信息时出错: " + e.getMessage());
            }
        } else if (api.getPartyUtils(player).isJoinedParty() && api.isPartyLeader(player)) {
            // 如果目标不在组队中，且你是队长，提供邀请选项
            TextComponent message = new TextComponent(ChatColor.translateAlternateColorCodes('&', "&e点击 "));
            TextComponent invite = new TextComponent(ChatColor.translateAlternateColorCodes('&', "&a[邀请加入]"));
            invite.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/party invite " + target.getName()));
            invite.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("点击邀请加入组队").create()));
            message.addExtra(invite);

            player.sendMessage(message);
        }
    }

    private void showAPIInfo(ProxiedPlayer player) {
        plugin.info(player, "&6=== BungeeFriends API 信息 ===");
        plugin.info(player, "&e版本: &71.0.0");
        plugin.info(player, "&e插件版本: &7" + plugin.getDescription().getVersion());
        plugin.info(player, "&e作者: &7SimplyRin (插件), Trae AI (API)");
        plugin.info(player, "&e描述: &7BungeeFriends插件的API接口，提供好友和组队功能的编程访问");
        plugin.info(player, "&e用法: &7在你的插件中使用 BungeeFriendsAPI.getInstance() 获取API实例");
    }

    @Override
    public Iterable<String> onTabComplete(CommandSender sender, String[] args) {
        List<String> results = new ArrayList<>();

        // 只有输入了字母才补全子命令
        if (args.length == 1 && !args[0].isEmpty()) {
            String input = args[0].toLowerCase();
            String[] options = {"help", "friends", "frienddetails", "frienddetailsbyname", "party", "partydetails", "partydetailsbyname", "check", "checkparty", "info"};
            for (String option : options) {
                if (option.startsWith(input)) {
                    results.add(option);
                }
            }
        } 
        // 只有输入了字母才补全玩家名
        else if (args.length == 2 && !args[1].isEmpty()) {
            if (args[0].equalsIgnoreCase("check") || args[0].equalsIgnoreCase("checkparty") || 
                args[0].equalsIgnoreCase("frienddetailsbyname") || args[0].equalsIgnoreCase("partydetailsbyname")) {
                // 只补全当前发送者所在服务器的玩家
                if (sender instanceof ProxiedPlayer) {
                    ProxiedPlayer senderPlayer = (ProxiedPlayer) sender;
                    String senderServer = senderPlayer.getServer().getInfo().getName();
                    String input = args[1].toLowerCase();
                    
                    for (ProxiedPlayer p : plugin.getProxy().getPlayers()) {
                        // 只添加同一服务器的玩家
                        if (p.getServer().getInfo().getName().equals(senderServer)) {
                            if (p.getName().toLowerCase().startsWith(input)) {
                                results.add(p.getName());
                            }
                        }
                    }
                }
            }
        }

        return results;
    }
}