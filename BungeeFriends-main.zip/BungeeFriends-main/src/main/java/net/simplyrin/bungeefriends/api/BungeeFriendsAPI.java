package net.simplyrin.bungeefriends.api;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.simplyrin.bungeefriends.BungeeFriends;
import net.simplyrin.bungeefriends.Main;
import net.simplyrin.bungeefriends.exceptions.AlreadyAddedException;
import net.simplyrin.bungeefriends.exceptions.FailedAddingException;
import net.simplyrin.bungeefriends.exceptions.FriendSlotLimitException;
import net.simplyrin.bungeefriends.exceptions.IgnoredException;
import net.simplyrin.bungeefriends.exceptions.NotAddedException;
import net.simplyrin.bungeefriends.exceptions.RequestDenyException;
import net.simplyrin.bungeefriends.exceptions.SelfException;
import net.simplyrin.bungeefriends.exceptions.parties.AlreadyJoinedException;
import net.simplyrin.bungeefriends.exceptions.parties.FailedInvitingException;
import net.simplyrin.bungeefriends.exceptions.parties.NotInvitedException;
import net.simplyrin.bungeefriends.exceptions.parties.NotJoinedException;
import net.simplyrin.bungeefriends.utils.FriendManager.FriendUtils;
import net.simplyrin.bungeefriends.utils.PartyManager.PartyUtils;

/**
 * BungeeFriends API 接口
 * 
 * @author SimplyRin, API by Trae AI
 * @version 1.0.0
 */
public class BungeeFriendsAPI {

    private static BungeeFriendsAPI instance;
    private Main plugin;

    /**
     * 获取API实例
     * 
     * @return API实例
     */
    public static BungeeFriendsAPI getInstance() {
        if (instance == null) {
            instance = new BungeeFriendsAPI();
        }
        return instance;
    }

    private BungeeFriendsAPI() {
        this.plugin = (Main) net.md_5.bungee.api.ProxyServer.getInstance().getPluginManager().getPlugin("BungeeFriends");
    }

    /**
     * 获取玩家的好友工具类
     * 
     * @param player 玩家
     * @return 好友工具类
     */
    public FriendUtils getFriendUtils(ProxiedPlayer player) {
        return this.plugin.getFriendManager().getPlayer(player);
    }

    /**
     * 获取玩家的好友工具类
     * 
     * @param uuid 玩家UUID
     * @return 好友工具类
     */
    public FriendUtils getFriendUtils(UUID uuid) {
        return this.plugin.getFriendManager().getPlayer(uuid);
    }

    /**
     * 获取玩家的组队工具类
     * 
     * @param player 玩家
     * @return 组队工具类
     */
    public PartyUtils getPartyUtils(ProxiedPlayer player) {
        return this.plugin.getPartyManager().getPlayer(player);
    }

    /**
     * 获取玩家的组队工具类
     * 
     * @param uuid 玩家UUID
     * @return 组队工具类
     */
    public PartyUtils getPartyUtils(UUID uuid) {
        return this.plugin.getPartyManager().getPlayer(uuid);
    }

    /**
     * 检查两个玩家是否是好友
     * 
     * @param player1 玩家1
     * @param player2 玩家2
     * @return 是否是好友
     */
    public boolean areFriends(ProxiedPlayer player1, ProxiedPlayer player2) {
        return this.getFriendUtils(player1).isFriend(player2.getUniqueId());
    }

    /**
     * 检查两个玩家是否是好友
     * 
     * @param uuid1 玩家1的UUID
     * @param uuid2 玩家2的UUID
     * @return 是否是好友
     */
    public boolean areFriends(UUID uuid1, UUID uuid2) {
        return this.getFriendUtils(uuid1).isFriend(uuid2);
    }

    /**
     * 添加好友请求
     * 
     * @param sender 发送者
     * @param target 目标玩家
     * @throws AlreadyAddedException 已经是好友
     * @throws FailedAddingException 添加失败
     * @throws SelfException 不能添加自己
     * @throws IgnoredException 被忽略
     * @throws FriendSlotLimitException 好友数量达到上限
     * @throws RequestDenyException 对方拒绝接收请求
     */
    public void addFriendRequest(ProxiedPlayer sender, ProxiedPlayer target) 
            throws AlreadyAddedException, FailedAddingException, SelfException, 
                   IgnoredException, FriendSlotLimitException, RequestDenyException {
        this.getFriendUtils(sender).addRequest(target);
    }

    /**
     * 添加好友
     * 
     * @param player1 玩家1
     * @param player2 玩家2
     * @throws AlreadyAddedException 已经是好友
     * @throws FailedAddingException 添加失败
     */
    public void addFriend(ProxiedPlayer player1, ProxiedPlayer player2) 
            throws AlreadyAddedException, FailedAddingException {
        this.getFriendUtils(player1).add(player2);
    }

    /**
     * 移除好友
     * 
     * @param player1 玩家1
     * @param player2 玩家2
     * @throws NotAddedException 不是好友
     * @throws SelfException 不能移除自己
     */
    public void removeFriend(ProxiedPlayer player1, ProxiedPlayer player2) 
            throws NotAddedException, SelfException {
        this.getFriendUtils(player1).remove(player2);
    }

    /**
     * 获取玩家的好友列表
     * 
     * @param player 玩家
     * @return 好友UUID列表
     */
    public List<String> getFriendList(ProxiedPlayer player) {
        return this.getFriendUtils(player).getFriends();
    }

    /**
     * 获取玩家的好友列表
     * 
     * @param uuid 玩家UUID
     * @return 好友UUID列表
     */
    public List<String> getFriendList(UUID uuid) {
        return this.getFriendUtils(uuid).getFriends();
    }

    /**
     * 邀请玩家加入组队
     * 
     * @param leader 队长
     * @param target 目标玩家
     * @throws AlreadyJoinedException 已经在队伍中
     * @throws FailedInvitingException 邀请失败
     */
    public void inviteToParty(ProxiedPlayer leader, ProxiedPlayer target) 
            throws AlreadyJoinedException, FailedInvitingException {
        this.getPartyUtils(leader).addRequest(target);
    }

    /**
     * 将玩家添加到组队
     * 
     * @param leader 队长
     * @param member 成员
     * @throws AlreadyJoinedException 已经在队伍中
     * @throws net.simplyrin.bungeefriends.exceptions.parties.FailedAddingException 添加失败
     */
    public void addToParty(ProxiedPlayer leader, ProxiedPlayer member) 
            throws AlreadyJoinedException, net.simplyrin.bungeefriends.exceptions.parties.FailedAddingException {
        this.getPartyUtils(leader).add(member);
    }

    /**
     * 从组队中移除玩家
     * 
     * @param leader 队长
     * @param member 成员
     * @throws NotJoinedException 不在队伍中
     */
    public void removeFromParty(ProxiedPlayer leader, ProxiedPlayer member) 
            throws NotJoinedException {
        this.getPartyUtils(leader).remove(member);
    }

    /**
     * 获取玩家所在组队的成员列表
     * 
     * @param player 玩家
     * @return 组队成员UUID列表
     */
    public List<String> getPartyMembers(ProxiedPlayer player) {
        return this.getPartyUtils(player).getParties();
    }

    /**
     * 检查玩家是否在组队中
     * 
     * @param player 玩家
     * @return 是否在组队中
     */
    public boolean isInParty(ProxiedPlayer player) {
        return this.getPartyUtils(player).isJoinedParty();
    }

    /**
     * 获取玩家所在组队的队长
     * 
     * @param player 玩家
     * @return 队长的PartyUtils，如果不在队伍中则抛出异常
     * @throws NotJoinedException 不在队伍中
     */
    public PartyUtils getPartyLeader(ProxiedPlayer player) throws NotJoinedException {
        return this.getPartyUtils(player).getPartyLeader();
    }

    /**
     * 检查玩家是否是队长
     * 
     * @param player 玩家
     * @return 是否是队长
     */
    public boolean isPartyLeader(ProxiedPlayer player) {
        try {
            return this.getPartyUtils(player).isPartyOwner();
        } catch (NotJoinedException e) {
            return false;
        }
    }

    /**
     * 发送组队聊天消息
     * 
     * @param player 玩家
     * @param message 消息
     * @throws NotJoinedException 不在队伍中
     */
    public void sendPartyChat(ProxiedPlayer player, String message) throws NotJoinedException {
        this.getPartyUtils(player).partyChat(player, message);
    }

    /**
     * 获取玩家的好友详细信息列表
     * 
     * @param player 玩家
     * @return 好友详细信息列表，每个元素包含UUID、名称、显示名称和前缀
     */
    public List<FriendInfo> getFriendDetailList(ProxiedPlayer player) {
        return this.getFriendDetailList(player.getUniqueId());
    }

    /**
     * 获取玩家的好友详细信息列表
     * 
     * @param uuid 玩家UUID
     * @return 好友详细信息列表，每个元素包含UUID、名称、显示名称和前缀
     */
    public List<FriendInfo> getFriendDetailList(UUID uuid) {
        List<FriendInfo> result = new ArrayList<>();
        FriendUtils friendUtils = this.getFriendUtils(uuid);
        List<String> friendUUIDs = friendUtils.getFriends();
        
        for (String friendUUID : friendUUIDs) {
            FriendUtils friend = this.getFriendUtils(UUID.fromString(friendUUID));
            FriendInfo info = new FriendInfo();
            info.setUuid(friend.getUniqueId());
            info.setName(friend.getName());
            info.setDisplayName(friend.getDisplayName());
            info.setPrefix(friend.getPrefix());
            info.setOnline(friend.getPlayer() != null);
            result.add(info);
        }
        
        return result;
    }

    /**
     * 通过玩家名称获取该玩家的好友详细信息列表
     * 
     * @param playerName 玩家名称
     * @return 好友详细信息列表，每个元素包含UUID、名称、显示名称和前缀，如果玩家不存在则返回空列表
     */
    public List<FriendInfo> getFriendDetailListByName(String playerName) {
        UUID uuid = this.plugin.getPlayerManager().getPlayerUniqueId(playerName);
        if (uuid == null) {
            return new ArrayList<>(); // 玩家不存在，返回空列表
        }
        return this.getFriendDetailList(uuid);
    }

    /**
     * 获取玩家所在组队的成员详细信息列表
     * 
     * @param player 玩家
     * @return 组队成员详细信息列表，每个元素包含UUID、名称、显示名称和是否在线
     */
    public List<PartyMemberInfo> getPartyMemberDetailList(ProxiedPlayer player) {
        return this.getPartyMemberDetailList(player.getUniqueId());
    }

    /**
     * 获取玩家所在组队的成员详细信息列表
     * 
     * @param uuid 玩家UUID
     * @return 组队成员详细信息列表，每个元素包含UUID、名称、显示名称和是否在线
     */
    public List<PartyMemberInfo> getPartyMemberDetailList(UUID uuid) {
        List<PartyMemberInfo> result = new ArrayList<>();
        PartyUtils partyUtils = this.getPartyUtils(uuid);
        
        if (!partyUtils.isJoinedParty()) {
            return result; // 返回空列表，因为玩家不在任何组队中
        }
        
        try {
            // 添加队长信息
            PartyUtils leader = partyUtils.getPartyLeader();
            PartyMemberInfo leaderInfo = new PartyMemberInfo();
            leaderInfo.setUuid(leader.getUniqueId());
            leaderInfo.setName(this.getFriendUtils(leader.getUniqueId()).getName());
            leaderInfo.setDisplayName(leader.getDisplayName());
            leaderInfo.setOnline(leader.getPlayer() != null);
            leaderInfo.setLeader(true);
            result.add(leaderInfo);
            
            // 添加其他成员信息
            List<String> memberUUIDs = leader.getParties();
            for (String memberUUID : memberUUIDs) {
                if (memberUUID.equals(leader.getUniqueId().toString())) {
                    continue; // 跳过队长，因为已经添加过了
                }
                
                PartyUtils member = this.getPartyUtils(UUID.fromString(memberUUID));
                PartyMemberInfo memberInfo = new PartyMemberInfo();
                memberInfo.setUuid(member.getUniqueId());
                memberInfo.setName(this.getFriendUtils(member.getUniqueId()).getName());
                memberInfo.setDisplayName(member.getDisplayName());
                memberInfo.setOnline(member.getPlayer() != null);
                memberInfo.setLeader(false);
                result.add(memberInfo);
            }
        } catch (NotJoinedException e) {
            // 不应该发生，因为已经检查了isJoinedParty
        }
        
        return result;
    }

    /**
     * 通过玩家名称获取该玩家所在组队的成员详细信息列表
     * 
     * @param playerName 玩家名称
     * @return 组队成员详细信息列表，每个元素包含UUID、名称、显示名称和是否在线，如果玩家不存在或不在队伍中则返回空列表
     */
    public List<PartyMemberInfo> getPartyMemberDetailListByName(String playerName) {
        UUID uuid = this.plugin.getPlayerManager().getPlayerUniqueId(playerName);
        if (uuid == null) {
            return new ArrayList<>(); // 玩家不存在，返回空列表
        }
        return this.getPartyMemberDetailList(uuid);
    }

    /**
     * 好友信息类
     */
    public static class FriendInfo {
        private UUID uuid;
        private String name;
        private String displayName;
        private String prefix;
        private boolean online;
        
        public UUID getUuid() {
            return uuid;
        }
        
        public void setUuid(UUID uuid) {
            this.uuid = uuid;
        }
        
        public String getName() {
            return name;
        }
        
        public void setName(String name) {
            this.name = name;
        }
        
        public String getDisplayName() {
            return displayName;
        }
        
        public void setDisplayName(String displayName) {
            this.displayName = displayName;
        }
        
        public String getPrefix() {
            return prefix;
        }
        
        public void setPrefix(String prefix) {
            this.prefix = prefix;
        }
        
        public boolean isOnline() {
            return online;
        }
        
        public void setOnline(boolean online) {
            this.online = online;
        }
    }

    /**
     * 组队成员信息类
     */
    public static class PartyMemberInfo {
        private UUID uuid;
        private String name;
        private String displayName;
        private boolean online;
        private boolean leader;
        
        public UUID getUuid() {
            return uuid;
        }
        
        public void setUuid(UUID uuid) {
            this.uuid = uuid;
        }
        
        public String getName() {
            return name;
        }
        
        public void setName(String name) {
            this.name = name;
        }
        
        public String getDisplayName() {
            return displayName;
        }
        
        public void setDisplayName(String displayName) {
            this.displayName = displayName;
        }
        
        public boolean isOnline() {
            return online;
        }
        
        public void setOnline(boolean online) {
            this.online = online;
        }
        
        public boolean isLeader() {
            return leader;
        }
        
        public void setLeader(boolean leader) {
            this.leader = leader;
        }
    }
}