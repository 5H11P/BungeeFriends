package net.simplyrin.bungeefriends.exceptions;

/**
 * Created by SimplyRin on 2018/08/31.
 *
 * author: SimplyRin
 * license: LGPL v3
 * copyright: Copyright (c) 2021 SimplyRin
 */
public class SelfException extends Exception {

	public SelfException() {
	}

}
